<div align="center">

# 🎯 JobTracker

**AI-powered job vacancy aggregator from Telegram channels → Notion**

Automatically parses job postings from Telegram channels, extracts structured data using AI, and saves everything to a Notion database with full tracking.

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![Telegram](https://img.shields.io/badge/Telegram-API-26A5E4?style=for-the-badge&logo=telegram&logoColor=white)](https://core.telegram.org)
[![Notion](https://img.shields.io/badge/Notion-API-000000?style=for-the-badge&logo=notion&logoColor=white)](https://developers.notion.com)
[![AI](https://img.shields.io/badge/AI-Qwen-FF6B35?style=for-the-badge&logo=openai&logoColor=white)](https://www.alibabacloud.com/product/dashscope)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

[🇷🇺 README на русском](README.ru.md)

</div>

---

## 🧩 How It Works

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Telegram    │ ──▶ │   AI Parser  │ ──▶ │    Notion    │
│   Channels    │     │   (Qwen)     │     │   Database   │
└──────────────┘     └──────────────┘     └──────────────┘
```

1. **Reads** messages from Telegram job channels via Telethon
2. **Analyzes** each message with Qwen AI — determines if it's a vacancy
3. **Extracts** structured fields: title, company, salary, location, format, contacts
4. **Deduplicates** against existing entries in Notion
5. **Saves** to Notion table with direct link to original Telegram message

## ✨ Features

- 🤖 **AI-Powered Parsing** — handles unstructured Russian & English job posts
- 📡 **Batch & Live modes** — one-time scan or real-time monitoring
- 🔗 **Direct TG links** — each vacancy links back to the original message
- 🚫 **Deduplication** — won't add the same job twice
- 📊 **Notion Dashboard** — track status, add notes, manage applications
- ⚙️ **Configurable** — choose channels, message limits, AI model via `.env`

## 📋 Notion Table Structure

| Column | Type | Description |
|--------|------|-------------|
| Должность | Title | Job title |
| Компания | Text | Company name |
| Статус | Select | Новая → Отправлено → Собеседование → Оффер/Отказ |
| Ссылка на вакансию | URL | Link to vacancy or TG message |
| Ссылка на HR | URL | HR contact link |
| Зарплата | Text | Salary range |
| Локация | Text | City / Country |
| Формат работы | Select | Офис / Удалёнка / Гибрид |
| Источник | Select | Telegram / LinkedIn / hh.ru |
| ТГ-канал | Text | Source channel |
| Заметки | Text | Key requirements |

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/AntonShuverov/job-tracker.git
cd job-tracker
pip install -r requirements.txt
```

### 2. Get API Keys

| Service | Where | What you need |
|---------|-------|---------------|
| Telegram | [my.telegram.org](https://my.telegram.org) | `api_id` + `api_hash` |
| Qwen AI | [dashscope.console.aliyun.com](https://dashscope.console.aliyun.com) | API Key |
| Notion | [notion.so/profile/integrations](https://www.notion.so/profile/integrations) | Integration Token |

### 3. Configure

```bash
cp .env.example .env
# Edit .env with your keys
```

### 4. Set Up Notion

Create a database with the columns listed above, or duplicate [our template](#). Connect your Notion integration to the page (••• → Connect to).

### 5. Run

```bash
# One-time scan of recent messages
python run.py

# Real-time monitoring
python run.py --live
```

## 🗺️ Roadmap

- [x] **v1** — Telegram channels → Notion (AI parsing)
- [ ] **v2** — LinkedIn job search (Russian-language filter)
- [ ] **v3** — hh.ru API integration + all platforms
- [ ] **v4** — AI-generated cover letters
- [ ] **v5** — Telegram bot for notifications & management

## 📁 Project Structure

```
job_tracker/
├── tg_parser.py        # Core: TG parsing + AI + Notion
├── test_pipeline.py    # Test: manual text → AI → Notion
├── run.py              # Entry point with .env loading
├── .env.example        # Config template
├── .gitignore          # Git exclusions
└── requirements.txt    # Python dependencies
```

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| Language | Python 3.11+ |
| Telegram | Telethon (MTProto) |
| AI | Qwen API (OpenAI-compatible) |
| Database | Notion API |
| Future: LinkedIn | JobSpy |
| Future: hh.ru | Official API |

## 📄 License

MIT — feel free to use and modify.

## ⭐ Star this repo

If this project helped you automate your job search — give it a ⭐!

---

<div align="center">
  <sub>Built with ❤️ and AI assistance</sub>
</div>
