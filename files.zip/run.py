"""
JobTracker — точка входа.
Загружает .env и запускает парсер.
"""
import sys
from dotenv import load_dotenv

load_dotenv()

if "--live" in sys.argv:
    import os
    os.environ["MODE"] = "live"

from tg_parser import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())
