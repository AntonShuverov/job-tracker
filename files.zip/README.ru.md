<div align="center">

# 🎯 JobTracker

**Автоматический парсинг вакансий из Telegram-каналов → Notion**

Парсит вакансии из ТГ-каналов, анализирует текст через ИИ, извлекает структурированные данные и сохраняет в таблицу Notion с трекингом откликов.

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![Telegram](https://img.shields.io/badge/Telegram-API-26A5E4?style=for-the-badge&logo=telegram&logoColor=white)](https://core.telegram.org)
[![Notion](https://img.shields.io/badge/Notion-API-000000?style=for-the-badge&logo=notion&logoColor=white)](https://developers.notion.com)
[![AI](https://img.shields.io/badge/AI-Qwen-FF6B35?style=for-the-badge&logo=openai&logoColor=white)](https://www.alibabacloud.com/product/dashscope)

[🇬🇧 English README](README.md)

</div>

---

## 🧩 Как это работает

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Telegram    │ ──▶ │  ИИ-парсер   │ ──▶ │    Notion    │
│   каналы      │     │   (Qwen)     │     │   таблица    │
└──────────────┘     └──────────────┘     └──────────────┘
```

1. **Читает** сообщения из Telegram-каналов с вакансиями через Telethon
2. **Анализирует** каждое сообщение через Qwen AI — вакансия или нет?
3. **Извлекает** поля: должность, компания, зарплата, локация, формат, контакт
4. **Проверяет** дубликаты в Notion
5. **Записывает** в таблицу со ссылкой на исходное сообщение в Telegram

## ✨ Возможности

- 🤖 **ИИ-парсинг** — разбирает неструктурированные тексты вакансий на русском и английском
- 📡 **Два режима** — одноразовый парсинг (batch) или мониторинг в реальном времени (live)
- 🔗 **Ссылки на ТГ** — каждая вакансия содержит ссылку на оригинальное сообщение
- 🚫 **Дедупликация** — не добавляет одну и ту же вакансию дважды
- 📊 **Notion-дашборд** — статусы, заметки, сопроводительные письма
- ⚙️ **Гибкая настройка** — каналы, лимиты, модель ИИ через `.env`

## 🚀 Быстрый старт

### 1. Клонируй и установи

```bash
git clone https://github.com/AntonShuverov/job-tracker.git
cd job-tracker
pip install -r requirements.txt
```

### 2. Получи API-ключи

| Сервис | Где получить | Что нужно |
|--------|-------------|-----------|
| Telegram | [my.telegram.org](https://my.telegram.org) | `api_id` + `api_hash` |
| Qwen AI | [dashscope.console.aliyun.com](https://dashscope.console.aliyun.com) | API Key |
| Notion | [notion.so/profile/integrations](https://www.notion.so/profile/integrations) | Integration Token |

### 3. Настрой

```bash
cp .env.example .env
# Заполни .env своими ключами
```

### 4. Настрой Notion

Создай таблицу с нужными колонками (или скопируй шаблон). Подключи интеграцию к странице через ••• → Connect to.

### 5. Запусти

```bash
# Одноразовый парсинг последних сообщений
python run.py

# Мониторинг в реальном времени
python run.py --live
```

## 🗺️ Дорожная карта

- [x] **v1** — Telegram-каналы → Notion (ИИ-парсинг)
- [ ] **v2** — Поиск на LinkedIn (фильтр русскоязычных вакансий)
- [ ] **v3** — hh.ru API + все площадки
- [ ] **v4** — ИИ-генерация сопроводительных писем
- [ ] **v5** — Telegram-бот для уведомлений и управления

## 📁 Структура проекта

```
job_tracker/
├── tg_parser.py        # Ядро: ТГ-парсинг + ИИ + Notion
├── test_pipeline.py    # Тест: ручной ввод → ИИ → Notion
├── run.py              # Точка входа, загрузка .env
├── .env.example        # Шаблон конфигурации
├── .gitignore          # Исключения Git
└── requirements.txt    # Зависимости Python
```

## 🛠️ Технологии

| Компонент | Технология |
|-----------|-----------|
| Язык | Python 3.11+ |
| Telegram | Telethon (MTProto) |
| ИИ | Qwen API (OpenAI-совместимый) |
| База данных | Notion API |
| Будущее: LinkedIn | JobSpy |
| Будущее: hh.ru | Официальный API |

## 📄 Лицензия

MIT — используй и модифицируй свободно.

---

<div align="center">
  <sub>Сделано с ❤️ и помощью ИИ</sub>
</div>
